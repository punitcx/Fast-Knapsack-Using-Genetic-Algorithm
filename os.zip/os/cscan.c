#include<stdio.h>
int pattern[20];
int n,start,work=0;
void sort(){
	int i,j,temp;
	for(i=0;i<n-1;i++){
		for(j=0;j<n-i-1;j++){
			if(pattern[j]<pattern[j+1])
				{
					temp=pattern[j];
					pattern[j]=pattern[j+1];
					pattern[j+1]=temp;
				}
		}
	}

}
void main()
{
	int i,j,end;
	printf("Give N ");
	scanf("%d",&n);
	printf("Give start");
	scanf("%d",&start);
	printf("Give Size");
	scanf("%d",&end);
	for(i=0;i<n;i++){
		scanf("%d",&pattern[i]);
		if(pattern[i]>start){
			pattern[i]=pattern[i]-end;
		}
	}
	sort();
	printf("Head movement:");
	for(i=0;i<n;i++){
		if(start>0)
			printf("%d ",abs(start));
		else
				printf("%d ",start+end);
		work+=abs(pattern[i]-start);
		start=pattern[i];
	}
	if(start>0)
		printf("%d",start);
	else
		printf("%d",start+end);
	printf("\n Total Work :%d",work);	
}
/*
Give N 5
Give start50
Give Size100
40
30
90
80
70
Head movement:50 40 30 90 80 70
 Total Work :80
*/
