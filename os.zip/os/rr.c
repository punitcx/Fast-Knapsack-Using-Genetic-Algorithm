#include<stdio.h>
#include<stdlib.h>
int burst1[100]={3,4,3},burst[100]={3,4,3},n=3,q=1,wait[]={0,0,0},t=0;
int main(){
    int i=0,j,k,l,com=0;
    while(1){
        com=0;
        for ( i = 0; i < 3; i++)
        {
            if(burst[i]>0){
                com=1;
                if(burst[i]>q){
                    t=t+q;
                    burst[i]-=q;
                }
                else
                {
                    t=t+burst[i];
                    wait[i]=t-burst1[i];
                    burst[i]=0;
                }
                
            }
        }
        if (com)
        {
            break;
        }
        
    }
    printf("%d %d %d\n",burst[0],burst[1],burst[2]);
    printf("%d %d %d",wait[0],wait[1],wait[2]);
    return 0;
}