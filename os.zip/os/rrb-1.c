#include<stdio.h>
void main(){
	int process[10];//remaining time
	int entrytime[10];
	int bursttime[10];
	int i,j,n,flag=1,time=0,qt;
	float tt=0,wt=0;
	printf("Give Number of Process And QT::");
	scanf("%d %d",&n,&qt);
	for(i=0;i<n;i++){
		printf("Give B Time of %d th process:",i);
		scanf("%d",&process[i]);
		bursttime[i]=0;
		entrytime[i]=process[i];	
	}
	while(flag){
		flag=0;
		for(i=0;i<n;i++){
			if(process[i]>0){
				flag=1;
				if(process[i]>qt){
					time=time+qt;
					process[i]=process[i]-qt;
				}
				else{
					time=time+process[i];
					bursttime[i]=time;
					process[i]=-1;
				}
			}	
		}
	}
	printf("Process\t\tT.A.T Time\tW.T\n");
	for(i=0;i<n;i++){
		printf("%d\t\t%d\t\t%d\n",i,bursttime[i],bursttime[i]-entrytime[i]);
		tt+=bursttime[i]/(float)n;
		wt+=(bursttime[i]-entrytime[i])/(float)n;
	}
	printf(" AVG TAT=%f AVG WT =%f ",tt,wt);
}/*
Give Number of Process And QT::5 2
Give B Time of 0 th process:2 
Give B Time of 1 th process:1
Give B Time of 2 th process:8
Give B Time of 3 th process:4
Give B Time of 4 th process:5
Process		T.A.T Time	W.T
0		2		0
1		3		2
2		20		12
3		13		9
4		18		13
 AVG TAT=11.200000 AVG WT =7.200000 
*/
