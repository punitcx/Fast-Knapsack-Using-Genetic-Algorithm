#include<stdio.h>
int pattern[20];
int n,start,work=0;
void sort(){
	int i,j,temp;
	for(i=0;i<n-1;i++){
		for(j=0;j<n-i-1;j++){
			if(pattern[j]<pattern[j+1])
				{
					temp=pattern[j];
					pattern[j]=pattern[j+1];
					pattern[j+1]=temp;
				}
		}
	}
}
void main()
{
	int i,j;
	printf("Give N ");
	scanf("%d",&n);
	printf("Give start");
	scanf("%d",&start);
	for(i=0;i<n;i++){
		scanf("%d",&pattern[i]);
		if(pattern[i]>start){
			pattern[i]=pattern[i]*-1;
		}
	}
	sort();
	printf("Head movement:");
	for(i=0;i<n;i++){
		if(start>0)
			printf("%d ",start);
		else{
				printf("%d ",start*-1);
			}
		if(start>0&&pattern[i]<0)
			work=work-abs(start)*2;
		work+=abs(pattern[i]-start);
		start=pattern[i];
	}
	if(start>0)
		printf("%d",start);
	else
		printf("%d",start*-1);
	printf("\n Total Work :%d",work);	
}
