#include<stdio.h>
int opt[20];
int page[20];
int frame[20];
int p,f;
int optimal(int start){
	int i;
	for(i=start+1;i<p;i++){
		if(page[start]==page[i])
			return i;
	}
	return i;		
}
int hit(int a){
	int i;
	for(i=0;i<f;i++){
		if(frame[i]==a)
			return i;
	}
	return -1;
}
int max(){
	int i,max,greed=-99;
	for(i=0;i<f;i++){
		if(greed<opt[i]){
			greed=opt[i];
			max=i;
		}
	}
	return max;
}
void main(){
	int i,j,t;
	//printf("Give Number of pages");
	scanf("%d",&p);
	//printf("Give Number of Frames");
	scanf("%d",&f);
	for(i=0;i<f;i++){
		frame[i]=-1;
		opt[i]=99;
	}
	for(i=0;i<p;i++){
		//printf("Give %d th page",i);
		scanf("%d",&page[i]);
	}
	for(i=0;i<p;i++){
		if(hit(page[i])!=-1){
			printf("Hit !\n");
			t=hit(page[i]);
			opt[t]=optimal(i);
		}
		else{
			printf("Miss !\n");
			t=max();
			//printf("%d",t);
			frame[t]=page[i];
			opt[t]=optimal(i);
		}
		for(j=0;j<f;j++)
			printf("%d ",frame[j]);
		printf("\n");
	}
}
/*
12
3
2 3 2 1 5 2 4 5 3 2 5 2
Miss !
2 -1 -1 
Miss !
2 3 -1 
Hit !
2 3 -1 
Miss !
2 3 1 
Miss !
2 3 5 
Hit !
2 3 5 
Miss !
4 3 5 
Hit !
4 3 5 
Hit !
4 3 5 
Miss !
2 3 5 
Hit !
2 3 5 
Hit !
2 3 5
*/
