echo "top 10 processses"
ps -eo pid,ppid,cmd,%cpu,%mem --sort=-%mem |head
echo "highest memory user process"
pd -eo pid,ppid,cmd,%cpu,%mem --sort=-%mem | head -n2
echo "current user"
whoami
echo "currentt shell/home-directory type/path/working directory"
pwd
echo "os infor"
cat /etc/os-release|grep NAME
