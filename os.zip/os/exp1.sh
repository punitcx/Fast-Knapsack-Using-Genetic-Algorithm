ls
mv
cp
pwd
cal
man
grep
cd
ll
la
chmod
chown

