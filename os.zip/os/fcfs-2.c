#include<stdio.h>
#include <stdlib.h>
#include<math.h>
int pattern[20],work=0,start;
int n;
void main()
{
	int i,j;
	printf("Give N ");
	scanf("%d",&n);
	printf("Give start");
	scanf("%d",&start);
	for(i=0;i<n;i++){
		scanf("%d",&pattern[i]);
	}
	printf("Head movement:");
	for(i=0;i<n;i++){
		printf("%d ",start);
		work+=abs(pattern[i]-start);
		start=pattern[i];
	}
	printf("%d",start);
	printf("\n Total Work :%d",work);

}
