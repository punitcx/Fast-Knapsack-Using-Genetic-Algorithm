#include<stdio.h>
#include<stdlib.h>
int max(int *x){
    int max=0;
    if(x[1]>x[max]){
        max=1;
        if(x[2]>x[max]){
            max=2;
        }
    }
    else if (x[2]>x[max])
    {
        max=2;
    }
    return max;
    
}

int check(int x,int *s){
    int i;  
    for(i=0;i<3;i++){
        if(s[i]==x){

            return 1;
        }
    }
    return 0;
}
int main(){
    int p[]={7,0,1,2,0,3,0,4,2,3,0,3,2,1,2,0,1,7,0,1},n,i,j,k,m;
    int l[]={-1,-1,-1},count[]={-99,-99,-99},hit=0,pos;
    for(i=0;i<20;i++){
        if(i<3){
            if(check(p[i],l)){
                hit++;
                count[0]++;
                count[1]++;
                count[2]++;
                printf("%d\t%d %d %d\t%d %d %d\n",p[i],l[0],l[1],l[2],count[0],count[1],count[2]);
            }
            else{
                l[i]=p[i];
                count[i]=1;
                for(m=0;m<3;m++){
                    if(m!=i){
                        count[m]++;
                    }
                }
                printf("%d\t%d %d %d\t%d %d %d\n",p[i],l[0],l[1],l[2],count[0],count[1],count[2]);
            }
        }
        else{
            if(check(p[i],l)){
                hit++;
                count[0]++;
                count[1]++;
                count[2]++;
                printf("%d\t%d %d %d\t%d %d %d\n",p[i],l[0],l[1],l[2],count[0],count[1],count[2]);

            }
            else{
                
                pos=max(count);
                l[pos]=p[i];
                count[pos]=1;
                for(m=0;m<3;m++){
                    if(m!=pos){
                        count[m]++;
                    }
                }
                printf("%d\t%d %d %d\t%d %d %d\n",p[i],l[0],l[1],l[2],count[0],count[1],count[2]);
            }
        }
    }
    printf("%d\n",hit);
    return 0;
}