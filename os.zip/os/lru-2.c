#include<stdio.h>
int lru[20];
int page[20];
int frame[20];
int p,f;
int hit(int a){
	int i;
	for(i=0;i<f;i++){
		if(frame[i]==a)
			return i;
	}
	return -1;
}
int min(){
	int i,min,greed=99;
	for(i=0;i<f;i++){
		if(greed>lru[i]){
			greed=lru[i];
			min=i;
		}
	}
	return min;
}
void main(){
	int i,j,t;
	//printf("Give Number of pages");
	scanf("%d",&p);
	//printf("Give Number of Frames");
	scanf("%d",&f);
	for(i=0;i<f;i++){
		frame[i]=-1;
		lru[i]=-99;
	}
	for(i=0;i<p;i++){
		//printf("Give %d th page",i);
		scanf("%d",&page[i]);
		if(hit(page[i])!=-1){
			printf("Hit !\n");
			t=hit(page[i]);
			lru[t]=i;
		}
		else{
			printf("Miss !\n");
			t=min();
			//printf("%d",t);
			frame[t]=page[i];
			lru[t]=i;
		}
		for(j=0;j<f;j++)
			printf("%d ",frame[j]);
		printf("\n");
	}
}
/*
12
3
2 3 2 1 5 2 4 5 3 2 5 2
Miss !
2 -1 -1 
Miss !
2 3 -1 
Hit !
2 3 -1 
Miss !
2 3 1 
Miss !
2 5 1 
Hit !
2 5 1 
Miss !
2 5 4 
Hit !
2 5 4 
Miss !
3 5 4 
Miss !
3 5 2 
Hit !
3 5 2 
Hit ! 
*/
