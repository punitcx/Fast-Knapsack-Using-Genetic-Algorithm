echo "the  first variable is $1 "
echo "the second variable is $2 "
